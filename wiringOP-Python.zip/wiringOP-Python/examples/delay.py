# Demonstrates use of Arduino-like delay function
import wiringpi
print 'Hello World'
wiringpi.delay(1500) # Delay for 1.5 seconds
print 'Hi again!'
